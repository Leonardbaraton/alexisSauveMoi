module Main (main) where

import Codec.Picture
import Codec.Picture.RGBA8
import Data.Word (Word8)
import Control.Monad (forM_)
import System.IO (writeFile)
import Data.List (sortBy)
import Data.Ord (comparing)

-- Fonction pour lire l'image et en extraire les pixels
extractPixels :: FilePath -> IO ()
extractPixels filePath = do
    -- Lire l'image
    eitherImage <- readImage filePath
    case eitherImage of
        Left err -> putStrLn $ "Erreur lors de la lecture de l'image : " ++ err
        Right dynImage -> do
            -- Convertir l'image en RGB8
            let image = convertRGB8 dynImage
            -- Récupérer tous les pixels
            let pixels = [(x, y, pixelAt image x y) | y <- [0..imageHeight image - 1], x <- [0..imageWidth image - 1]]
            -- Trier les pixels en fonction de la composante rouge
            let sortedPixels = sortBy (comparing (getRed . thd)) pixels
            -- Recréer l'image avec les pixels triés
            let newImage = recreateImage (imageWidth image) (imageHeight image) sortedPixels
            -- Sauvegarder la nouvelle image
            savePngImage "sorted_image.png" (ImageRGB8 newImage)
            putStrLn "Nouvelle image enregistrée sous 'sorted_image.png'"

-- Extraire la composante rouge d'un pixel
getRed :: PixelRGB8 -> Word8
getRed (PixelRGB8 r _ _) = r

-- Recréer une image à partir des pixels triés
recreateImage :: Int -> Int -> [(Int, Int, PixelRGB8)] -> Image PixelRGB8
recreateImage width height sortedPixels = generateImage pixelFunc width height
  where
    -- Remplir chaque pixel de l'image avec les pixels triés
    pixelFunc x y = let (_, _, px) = sortedPixels !! (y * width + x) in px

-- Convertir les pixels en texte pour les écrire dans un fichier
pixelsToText :: Image PixelRGB8 -> String
pixelsToText img = unlines [pixelToText (pixelAt img x y) | y <- [0..imageHeight img - 1], x <- [0..imageWidth img - 1]]

-- Convertir un pixel RGB8 en chaîne de caractères
pixelToText :: PixelRGB8 -> String
pixelToText (PixelRGB8 r g b) = show r ++ " " ++ show g ++ " " ++ show b

main :: IO ()
main = do
    -- Remplace par le chemin de ton fichier image
    extractPixels "image.png"
